package com.dicoding.movieapp.data.source.remote

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}