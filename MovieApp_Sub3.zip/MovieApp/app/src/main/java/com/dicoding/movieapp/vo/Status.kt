package com.dicoding.movieapp.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}